import UIKit

var greeting = "Hello, playground"

let pi = 3.14
print(pi)


var age : Int = 2;
age = age * 2


var course1 = "ios"
var course2 = "java"

print(course1 , "-", course2)


print(10,20,30)
print(10,20,30,separator: "\n")

//tuples

var http = (code:404, message:"not found", Nocode:500, message1:"INT server error")
print(http)
print(http.code, terminator: "--")
print(http.3)

var name = ("sirisha", "panuganti")

var origin = (x:0,y:0)
var point = origin
print(origin)
print(point)

var cricketkit = ("gloves", "helmet",("ball","bat"))
print(cricketkit.2.0)


var one : Double = 20
var two : Double = 15
print(one/two)


var num1 = (3,3)
var num2 = (3,4)

print(num1>num2)

//functions:

func getGreeting(){
    print("Welcome")
}
getGreeting()


func sayHello() -> String{
    return "Hello"
}

var msg = sayHello()
print(msg)
print(sayHello())


func favouriteProgram(_ myname: String) -> String{
    var name = " My fav prog is  \(myname)"
    return name;
}

print(favouriteProgram( "java"))


func calcAvg(_ numbers : Double...) -> (sum: Double,avg: Double){
    var sum : Double = 0.0;
    //sum = sum + numbers
    for num in numbers{
        sum = sum + num
    }
    var avg : Double = Double(sum/Double(numbers.count))
    return (sum,avg)
}

let result = calcAvg(1,2,4.5,3,7.5,7.9)
print(result.avg,result.sum)
print(calcAvg(1,2,4.5,3,7.5,7.9) )
